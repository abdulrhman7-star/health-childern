package com.example.doctorconsultantapp;

public class Doctor_Global_Class {
   static String dname ="..";
    static String category = "..";
    static String dphone = "...";
}
