package com.example.doctorconsultantapp;

public class slotdetails {

    String did;

    String slotend;
    String slotstart;
    String day;
    String scheduleid;

    public slotdetails() {

    }

    public String getDid() {
        return did;
    }

    public void setDid(String did) {
        this.did = did;
    }

    public String getSlotend() {
        return slotend;
    }

    public void setSlotend(String slotend) {
        this.slotend = slotend;
    }

    public String getSlotstart() {
        return slotstart;
    }

    public void setSlotstart(String slotstart) {
        this.slotstart = slotstart;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getScheduleid() {
        return scheduleid;
    }

    public void setScheduleid(String scheduleid) {
        this.scheduleid = scheduleid;
    }
}
