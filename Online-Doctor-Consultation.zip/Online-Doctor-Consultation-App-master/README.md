# Online-Doctor-Consultation-App
Online Doctor consultation is a Android Application provide the feature of Booking Appointment online with the Doctor and it also Provide the feature of consulting with Doctor via Phone Call or Video Call( through Whats'App). This Application is using the Firebase Database for storing and Fetching the data in Realtime.
